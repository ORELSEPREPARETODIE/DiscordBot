from discord.ext import commands, tasks
import discord, random

initial_extensions = ['cogs.roblox','cogs.fun','cogs.giveaway']
prefix = '-'
token = 'tokenhere'
bot = commands.Bot(command_prefix=prefix, description='Giveaway Bot')
bot.remove_command('help')
if __name__ == '__main__':
    for extension in initial_extensions:
        bot.load_extension(extension)

@tasks.loop(minutes=1.0)
async def status_task():
    statuses = ['I like rolling in seawater.','Cows are cool and so are turtles.','Drinking vinegar with sugar is good.','Trees are tall.']
    await bot.change_presence(activity=discord.Game(name=random.choice(statuses)))

@bot.event
async def on_ready():
    print(f'Logged in as: {bot.user.name}')
    await bot.change_presence(activity=discord.Game(name="[Starting]"))
    status_task.start()
@bot.command()
async def help(ctx):
    embed = discord.Embed(title="Help Command")
    embed.add_field(name=f"{prefix}giveaway <time> <prize>")
    embed.add_field(name=f"{prefix}reroll <messageid>")
    embed.add_field(name=f"{prefix}giveawaycount")
    await ctx.send(embed=embed)


try:
    bot.run(token)
except Exception as e:
    print(str(e))
