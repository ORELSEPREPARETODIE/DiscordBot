import discord
import datetime
import time
import asyncio
import random
from discord.ext import commands
from discord import Embed
giveaways = []
colours = [discord.Color.green(), discord.Color.blue()]
role = "S_waraj"
class Giveaway(commands.Cog):
    def __init__(self, client):
        self.client = client
    
    @commands.command()
    @commands.has_role(role)
    async def giveaway(self, ctx, time: int, *, prize):
        """Starts the actual giveaway"""
        giveawayembed = discord.Embed(title="🎉 New Giveaway! 🎉",colour=random.choice(colours))

        giveawayembed.add_field(name="Prize", value=f"{prize}", inline=False)
        giveawayembed.add_field(name="Hosted by", value=f"{ctx.author.mention}", inline=False)
        giveawayembed.add_field(name="Ends in", value=f"{time}s")


        msg = await ctx.send(embed=giveawayembed)

        await msg.add_reaction("🎉")
        gid = f"{prize}_{random.randint(1000, 2000)}"
        giveaways.append(gid)
        await asyncio.sleep(time)
        giveaways.remove(gid)
        msg = await msg.channel.fetch_message(msg.id)
        winner = None
        
        for reaction in msg.reactions:
            if reaction.emoji == "🎉":
                users = await reaction.users().flatten()
                users.remove(self.client.user)
                winner = random.choice(users)

        if winner is not None:
            endembed = discord.Embed(
                title="Giveaway ended!",
                description=f"Prize: {prize}\nWinner: {winner}"
            )
            await ctx.author.send(f"The giveaway for: {prize} has ended! The winner was <@{winner.id}> ({winner.id})")
            await ctx.send(f"<@{winner.id}> has won the giveaway for prize: {prize}")
            #await msg.edit(embed=endembed)
        else:
            embed = discord.Embed(
                title="Giveaway ended!",
                description=f"Prize: {prize}\nWinner: None because no one entered."
            )
            #await msg.edit(embed=embed)
        
    @commands.command()
    async def giveawaycount(self, ctx):
        """ Gets how many giveaways are commencing in this server """
        await ctx.send(f"There are `{len(giveaways)}` going on in this server!")
    @commands.command()
    @commands.has_role(role)
    async def reroll(self, ctx, messageid):
        channel = ctx.channel
        msg = await channel.fetch_message(messageid)
        for reaction in msg.reactions:
            if reaction.emoji == "🎉":
                users = await reaction.users().flatten()
                winner = random.choice(users)
                await ctx.send(f"New winner: <@{winner.id}>")
    @commands.command()
    @commands.has_role(role)
    async def rgiveaway(self, ctx, time: int, *, prize, winnerid):
        giveawayembed = discord.Embed(title="🎉 New Giveaway! 🎉",colour=random.choice(colours))

        giveawayembed.add_field(name="Prize", value=f"{prize}", inline=False)
        giveawayembed.add_field(name="Hosted by", value=f"{ctx.author.mention}", inline=False)
        giveawayembed.add_field(name="Ends in", value=f"{time}s")


        msg = await ctx.send(embed=giveawayembed)

        await msg.add_reaction("🎉")
        gid = f"{prize}_{random.randint(1000, 2000)}"
        giveaways.append(gid)
        await asyncio.sleep(time)
        giveaways.remove(gid)
        msg = await msg.channel.fetch_message(msg.id)
        winner = winnerid

        if winner is not None:
            endembed = discord.Embed(
                title="Giveaway ended!",
                description=f"Prize: {prize}\nWinner: {winner}"
            )
            await ctx.author.send(f"The giveaway for: {prize} has ended! The winner was <@{winner}> ({winner})")
            await ctx.send(f"<@{winner}> has won the giveaway for prize: {prize}")
            #await msg.edit(embed=endembed)
        else:
            embed = discord.Embed(
                title="Giveaway ended!",
                description=f"Prize: {prize}\nWinner: None because no one entered."
            )
            #await msg.edit(embed=embed)

    @giveaway.error
    async def giveaway_error(self, ctx, error):
        await ctx.send(error)
        print(error)
        raise error

def setup(client):
    client.add_cog(Giveaway(client))